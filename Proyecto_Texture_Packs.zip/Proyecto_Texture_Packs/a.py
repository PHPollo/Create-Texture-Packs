import os
import shutil



main_folder = os.getcwd()

element_pack_folder = os.path.join(main_folder, 'Elements_Texture_Pack')
texture_pack_folder = os.path.join(main_folder, 'Folder_Texture_Pack')



def versionLocation(version: str):
    
    if version == '1.20.4':
        direction_assets = os.path.join(main_folder, 'Elements_Originals\\Minecraft_1.20.4\\assets')
        number_pack_format = 22
        
    try:
        return direction_assets, number_pack_format
    
    except UnboundLocalError:
        print(f'No se encuentra programado la base de la version {version} y por esto no pudo ser ejecutado correctamente el programa.')



def createFolderPack(name_texture_pack: str, number_pack_format: int, direction_assets: str):
    
    os.mkdir(os.path.join(texture_pack_folder, name_texture_pack))
    
    shutil.copytree(direction_assets, f'Folder_Texture_Pack\\{name_texture_pack}')
    
    with open(os.path.join(texture_pack_folder, name_texture_pack)) as folder:
        folder.write('\n{\n   "pack": {\n    "pack_format": ' + f'{number_pack_format}\n' + '    "description": "None"\n  }\n}')





if __name__ == '__main__':
    
    while True:
        
        options = ['1', '2']
        
        print('OPCIONES DE INTERACCIÓN:\n1° Crear un nuevo paquete de texturas (insertar 1)\n2° Modificar un paquete de textura(insertar 2)')
        respuestas = input('\n¿Qué opción quieres realizar?: ')
        
        if respuestas in options:
            break
            
    if respuestas == '1':     #Crear paquete de texturas
        
        name_texture_pack = str(input('\nInserta el nombre del nuevo paquete de texturas: '))
        
        while True:
        
            try: 
                version = str(input('\nInserte la versión de la cual estara construida el paquete de texturas: '))

                direction_assets, number_pack_format = versionLocation(version= version)
            
                break
            except TypeError:
                pass
        
        #createFolderPack(name_texture_pack= name_texture_pack, number_pack_format= number_pack_format, direction_assets= direction_assets)