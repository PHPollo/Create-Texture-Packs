#Librerias
import os
import shutil


#Carpetas
main_folder = os.getcwd()

element_pack_folder = os.path.join(main_folder, 'Elements_Texture_Pack')
texture_pack_folder = os.path.join(main_folder, 'Folder_Texture_Pack')



#Funciones.
def versionLocation(version: str):

    dict_number_pack_versions = {
        ('1.6.1', '1.6.2', '1.6.4', '1.7.2', '1.7.4', '1.7.5', '1.7.6', '1.7.7', '1.7.8', '1.7.9', '1.7.10', '1.8', '1.8.1', '1.8.2', '1.8.3', '1.8.4', '1.8.5', '1.8.6', '1.8.7', '1.8.8', '1.8.9') : 1,
        ('1.9', '1.9.1', '1.9.2', '1.9.3', '1.9.4', '1.10', '1.10.1', '1.10.2') : 2,
        ('1.11', '1.11.1', '1.11.2','1.12', '1.12.1', '1.12.2') : 3,
        ('1.13', '1.13.1', '1.13.2', '1.14', '1.14.1', '1.14.2', '1.14.3', '1.14.4') : 4,
        ('1.15', '1.15.1', '1.15.2', '1.16', '1.16.1') : 5,
        ('1.16.2', '1.16.3', '1.16.4', '16.5') : 6,
        ('1.17', '1.17.1') : 7,
        ('1.18', '1.18.1', '1.18.2') : 8,
        ('1.19', '1.19.1', '1.19.2') : 9,
        ('1.19.3') : 12,
        ('1.19.4') : 13,
        ('1.20', '1.20.1') : 15,
        ('1.20.2') : 18,
        ('1.20.3', '1.20.4') : 22,
        ('1.20.5') : 32,
        ('1.21') : 34
    }

    for keys in dict_number_pack_versions:
        if version in keys:
            number_pack_format = dict_number_pack_versions[keys]

    direction_assets = os.path.join(main_folder, 'Elements_Originals\\Minecraft_1.20.4')    
    
    try:
        return direction_assets, number_pack_format
    
    except UnboundLocalError:
        print(f'No se encuentra programado la la base de la versión {version} y  por esto no pudo ser ejecutado correctamente el programa.')





def versionUpdate(name_texture_pack: str, version: str):
    
    if os.path.isfile(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}', 'pack.mcmeta')):      #Resisamos si esxiste el archivo.
            
            #Creamos el diccionario de versiones.
            dict_number_pack_versions = {
                ('1.6.1', '1.6.2', '1.6.4', '1.7.2', '1.7.4', '1.7.5', '1.7.6', '1.7.7', '1.7.8', '1.7.9', '1.7.10', '1.8', '1.8.1', '1.8.2', '1.8.3', '1.8.4', '1.8.5', '1.8.6', '1.8.7', '1.8.8', '1.8.9') : 1,
                ('1.9', '1.9.1', '1.9.2', '1.9.3', '1.9.4', '1.10', '1.10.1', '1.10.2') : 2,
                ('1.11', '1.11.1', '1.11.2','1.12', '1.12.1', '1.12.2') : 3,
                ('1.13', '1.13.1', '1.13.2', '1.14', '1.14.1', '1.14.2', '1.14.3', '1.14.4') : 4,
                ('1.15', '1.15.1', '1.15.2', '1.16', '1.16.1') : 5,
                ('1.16.2', '1.16.3', '1.16.4', '16.5') : 6,
                ('1.17', '1.17.1') : 7,
                ('1.18', '1.18.1', '1.18.2') : 8,
                ('1.19', '1.19.1', '1.19.2') : 9,
                ('1.19.3') : 12,
                ('1.19.4') : 13,
                ('1.20', '1.20.1') : 15,
                ('1.20.2') : 18,
                ('1.20.3', '1.20.4') : 22,
                ('1.20.5') : 32,
                ('1.21') : 34
            }

            #Buscamos el valor de la version.
            for keys in dict_number_pack_versions:
                if version in keys:
                    number_pack_format = dict_number_pack_versions[keys]


            #Leemos todo el archivo.
            with open(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}', 'pack.mcmeta'), 'r') as file:
                content = file.readlines()
                new_content_file = ''

            #Cambiamos el valor de compatibilidad por la nueva
            for line in content:
                if line == content[3]:
                    list_number_versions = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '12', '13', '15', '18', '22', '33', '34']

                    for number in list_number_versions:
                        if line.split()[1] == number:
                            line = line.replace(f'{number}', f'{number_pack_format}')

                new_content_file = new_content_file + line
            
            try:
                #Rehacemos el archivo desde cero con los nuevos cambios            
                with open(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}', 'pack.mcmeta'), 'w') as file:
                    file.writelines(new_content_file)

            except FileNotFoundError:
                print(f'La versión {version} no existe. Vuelva a aprobar con una verión que exista dentro de minecraft')





def createFolderPack(name_texture_pack: str, number_pack_format: int, direction_assets: str):
    try:
        #Crear carpeta del paquete.
        os.mkdir(os.path.join(texture_pack_folder, name_texture_pack))

        
        #Copiar los elementos del paquete.
        shutil.copytree(direction_assets, f'{texture_pack_folder}\\{name_texture_pack}', dirs_exist_ok= True)

        
        #Insertamos el archivo pack.mcmeta.
        with open(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}', 'pack.mcmeta'), 'w') as folder:
            folder.write('\n{\n   "pack": {\n    "pack_format": ' + f'{number_pack_format}\n' + '    "description": "None"\n  }\n}')
    
    except FileExistsError:
        print(f'El paquete de texturas {name_texture_pack} existe.\nPruebe con otro nombre para crear el nuevo paquete de texturas.')





def modifyPackLogo(name_texture_pack: str):
    if name_texture_pack in os.listdir(texture_pack_folder) and os.path.isdir(os.path.join(texture_pack_folder, name_texture_pack)):     #Si existe el Directorio/Carpeta.

        if os.path.isfile(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\Logo.png')):       #Si existe la imagen

            os.remove(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\Logo.png'))

        try:

            shutil.move(src= os.path.join(element_pack_folder, 'Logo.png'), dst= os.path.join(f'{texture_pack_folder}\\{name_texture_pack}', 'Logo.png'))

        except FileNotFoundError:
            print('La imagen Logo.png no pudo ser encontrada en la carpeta Element_Texture_Pack.')

    else:
        print('\nEl packete de texturas no existe en la capeta de Folder_Texture_Pack')





def modifyPackItems(name_texture_pack: str):
    if name_texture_pack in os.listdir(texture_pack_folder) and os.path.isdir(os.path.join(texture_pack_folder, name_texture_pack)):     #Si existe el Directorio/Carpeta.

        try:
            items = os.listdir(os.path.join(element_pack_folder, 'Items'))

            #Se crea una variable que permite cerrar el proceso de la función luego de terminar el loop.
            close = False

            for item in items:      #Revisar el titulo de las imagenes existen el directorio de texturas items.
                
                if item not in os.listdir(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures','item')):

                    close = True

                    print(f'La imagen {item} no pudo se encontrada en el directorio de texturas item del paquete.')

            if close == True: return


            for item in items:
                
                os.remove(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures\\item', item))

                shutil.move(src= os.path.join(f'{element_pack_folder}\\Items', item), dst= os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures\\item', item))
                
        
        except FileNotFoundError:
            print(f'El paquete de texturas {name_texture_pack} no contiene el archivo assets en su contenido.')

    else:
        print('\nEl paquete de texturas no existe en la capeta de Folder_Texture_Pack')





def modifyModelArmorPlayer(name_texture_pack: str):
    if name_texture_pack in os.listdir(texture_pack_folder) and os.path.isdir(os.path.join(texture_pack_folder, name_texture_pack)):     #Si existe el Directorio/Carpeta.

        try:
            models = os.listdir(os.path.join(element_pack_folder, 'Models_Armor'))

            #Se crea una variable que permite cerrar el proceso de la función luego de terminar el loop.
            close = False

            for model in models:      #Revisar el titulo de las imagenes existen el directorio de texturas items.
                
                if model not in os.listdir(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures\\models','armor')):

                    close = True

                    print(f'La imagen {model} no pudo se encontrada en el directorio de texturas item del paquete.')

            if close == True: return


            for model in models:
                
                os.remove(os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures\\models\\armor', model))

                shutil.move(src= os.path.join(f'{element_pack_folder}\\Models_Armor', model), dst= os.path.join(f'{texture_pack_folder}\\{name_texture_pack}\\assets\\minecraft\\textures\\models\\armor', model))
                
        
        except FileNotFoundError:
            print(f'El paquete de texturas {name_texture_pack} no contiene el archivo assets en su contenido.')








if __name__ == '__main__':
    options = ['0', '1', '2', '3', '4']

    while True:
        print('\nOPCIONES DE INTERACCIÓN:\n',
              '1° Crear un nuevo paquete de texturas (insertar 0)\n',
              '2° Cambiar el contenido del archivo pack.mcmeta del paquete de texturas (insertar 1)\n',
              '3° Modificar logo del paquete de textura (insertar 2)\n',
              '4° Modificar imgenes y aspectos los de items del taquete de texturas (insertar 3)\n',
              '5° Modificar modelos de las armaduras del jugador (insertar 4)\n'
              '6° Modificar texturas de los bloques (insertar 5)\n')
        answer = input('¿Qué opción quieres realizar?: ')

        if answer in options: break
    



    if answer == '0':       #Crear nuevo paquete de texturas.

        while True:
            name_texture_pack = input('\nInserta el nombre del nuevo paquete de texturas: ')
            checker = input('Seguro que este será el nombre del paquete de texturas S/N. ').lower()

            if checker =='s': break
        
        while True:
            try:
                version = input('\nInserte la versión de la cual sería compatible el paquete de texturas: ')

                direction_assets, number_pack_format = versionLocation(version= version)
                break

            except TypeError: pass
        
        while True:
            print('\nNota: Todas las imagenes para el paquete de texturas deben encontrarse en las carpertas respectivas de Elements_Texture_Pack.')

            checker = input('\n¿Estás seguro de crear el nuvo paquete de texturas? S/N ').lower()

            if checker == 'n': pass

            if checker == 's': break

        
        #Se aplica todos los elementos.
        createFolderPack(name_texture_pack= name_texture_pack, number_pack_format= number_pack_format, direction_assets= direction_assets)
        modifyPackLogo(name_texture_pack= name_texture_pack)
        modifyPackItems(name_texture_pack= name_texture_pack)
        modifyModelArmorPlayer(name_texture_pack= name_texture_pack)



    if answer == '1':       #Cambiar conenido del archivo pack.mcmeta.

        print('\nNota: El paquete de texturas que se va a manipular se debe encontrar en la carpeta Folder_Texture_Pack y dentro de este debe existir el archivo pack.mcmeta')

        name_texture_pack = input('\nInserta el nombre del paquete de texturas que se desea modificar: ')
        
        options = ['pack_format', 'descripción']
        while True:
            print('\nOPCIONES DE MODIFICACIÓN:\n',
                  '1° Cambiar Pack_Format (Número de la versión)\n',
                  '2° Cambiar Descripción\n')
            answer = input('¿Qué opción quieres realizar?: ').replace(' ', '_').lower()

            if answer in options:
                break

            else:
                print('\nLa opción escrita no es valida. Prueba nuevamente en insertar la opción.')



        if answer == options[0]:
            
            version_update = input('\nInserta la versión compatible con el paquete de texturas: ')

            versionUpdate(name_texture_pack= name_texture_pack, version= version_update)


        elif answer == options[1]:

            print('Actualmente esta opción no se encuentra prorgamada')




    elif answer == '2':     #Modificar logo del paquete de texturas.
        
        print('\nNota: El paquete de texturas que se va a manipular se debe encontrar en la carpeta Folder_Texture_Pack y el logo debe encontrarse en la carpeta Element_Texture_Pack con sus nombres correspondientesy en formato png.',
              '\n(El nombre de la imagen que representara el paquete debe tener el nombre "pack" y por ultimo se eliminara la imagen anterior.)')
        name_texture_pack = input('\nInserta el nombre del paquete de texturas que se desea modificar: ')

        modifyPackLogo(name_texture_pack= name_texture_pack)
    


    elif answer == '3':    #Modificar imagenes de items del paquete de texturas.

        print('\nNota: El paquete de texturas que se va a manipular se debe encontrar en la carpeta Folder_Texture_Pack, además de que las nueva imagenes del paquete de texturas deben encontrarse en formato pdf y ubicarse en la carpeta de Elements_Texture_Pack\\Items',
              '\n(El nombre de las imagenes deben ser iguales al nombre de las texturas originales. (ejem: apple.png, blaze_rod.png, soul_lantern.png, etc.))')
        name_texture_pack = input('\nInserta el nombre del paquete de texturas que se desea modificar: ')

        modifyPackItems(name_texture_pack= name_texture_pack)



    elif answer == '4':     #Modificar el aspecto de modelos de las armaduras.
        
        print('\nNota: El paquete de texturas que se va a manipular se debe encontrar en la carpeta Folder_Texture_Pack, además, la imagen de los modelos de las armaduras nuevas deben encontrarse en formato pdf y por ultimo ubicarse en la carpeta Elements_Texture_Pack\\Models_Armor',
              '\n(El nombre de las imagenes deben ser iguales al nombre de las texturas originales. (ejem: turtle_layer_1.png, iron_layer_1.png, iron_layer_2.png, etc.))')
        
        name_texture_pack = input('\nInserta el nombre del paquete de texturas que se desea modificar: ')

        modifyModelArmorPlayer(name_texture_pack= name_texture_pack)